﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PingPong
{
    public partial class Form1 : Form
    {
        private int speed_vert = 4;
        private int speed_hor = 4;
        private int score = 0;
        public Form1()
        {
            InitializeComponent();

            timer.Enabled = true;
            Cursor.Hide();
            this.FormBorderStyle = FormBorderStyle.None;
            this.TopMost = true;
            this.Bounds = Screen.PrimaryScreen.Bounds;
            gamePanel.Top = background.Bottom - (background.Bottom / 10);
            loseLabel.Visible = false;
            loseLabel.Left = (background.Width / 2) - (loseLabel.Width / 2);
            loseLabel.Top = (background.Height / 2) - (loseLabel.Height / 2);
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
                this.Close();
            if (e.KeyCode == Keys.Enter)
            {
                timer.Enabled = true;
                gameBall.Left = 50;
                gameBall.Top = 70;
                speed_hor = 1;
                speed_vert = 1;
                score = 0;
                loseLabel.Visible = false;
                result.Text = "Результат: 0";
            }
        }

        private void timer_Tick(object sender, EventArgs e)
        {
            gamePanel.Left = Cursor.Position.X - (gamePanel.Width / 2);
            gameBall.Left += speed_hor;
            gameBall.Top += speed_vert;

            if (gameBall.Left <= background.Left)
               speed_hor *= -1;
            if (gameBall.Right >= background.Right)
                speed_hor *= -1;
            if (gameBall.Top <= background.Top)
                speed_vert *= -1;
            if (gameBall.Bottom >= background.Bottom)
                {
                    loseLabel.Visible = true;
                    timer.Enabled = false;
                }
            if (gameBall.Bottom >= gamePanel.Top
                && gameBall.Left <= gamePanel.Right && gameBall.Right >= gamePanel.Left)
            {
                speed_hor += 1;
                speed_vert += 1;
                speed_vert *= -1;
                score++;
                result.Text = "Результат: " + score.ToString();
                Random randColor = new Random();
                background.BackColor = Color.FromArgb(randColor.Next(150, 255), randColor.Next(150, 255), randColor.Next(150, 255));
            }

        }
    }
}
